package preferenceAnalysis;
import java.util.ArrayList;



public class genreAnalysis {
	
	public ArrayList<String> selectionGenre = new ArrayList<>(); 
	
	public void addSelectionGenre() {
		for
	}
	
}
