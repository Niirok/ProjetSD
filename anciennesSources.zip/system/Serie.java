// A inclure directement dans Media
package system;
public class Serie extends AbsVideo {
    static String type = "Serie";
    
    public Serie(String name, int year, String[] genre, String[] casting, int duration,String synop,String director) {
	super(name, year, genre, casting, duration,synop,director);
    }
    
    public String toString(){
	return super.toString();
    }
    public String getType(){
	return Serie.type;
    }
    
}
