//A supprimer

package system;
public interface MediaImpl  {
    public String toString(); 
}
